class student :
    def __init__(self,name,rollnum,marks):
        self.name = name
        self.rollnum = rollnum
        self.marks = marks
     



    def printAllDetails(self):
        print(self.name)
        print(self.rollnum)
        print(self.marks)
        
        
obj = student("harry",78,789)
obj.printAllDetails()


obj500 = student("mano",89,9)
obj500.printAllDetails()






class Node:
    def __init__(self,data):
        self.data = data
        self.next = None
        
obj1 = Node(10)
obj2 = Node(20)
obj3 = Node(30)
obj4 = Node(40)
obj5 = Node(50)




obj1.next = obj2
obj2.next = obj3
obj3.next = obj4
obj4.next = obj5
currentNode = obj1
while currentNode !=None:
    print(currentNode.data,end = "--<")
    currentNode = currentNode.next
    
    
    
    
    
def insertAtTail(head,ele):
    temp = Node(ele)
    if head == None:
        return temp
        
        
    tail = head
    while tail.next != None:
        tail = tail.next 
    tail.next = temp 
    return head
 
 
nums = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
head = None 
for ele in nums:
    head = insertAtTail(head, ele)
    printLinkedList(head)
print("Final linked list is:")
printLinkedList(head)
    
    
def deleteTailNode(head):
    if head == None or head.next == None:
        return None
        
    previous = None
    currentNode = head
    
    while currentNode.next != None:
        previous = currentNode
        currentNode = currentNode.next
        
    previous.next = None
    return head
    
    
    
    
    
    
    
    
    
    
    
    
































































































       


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


