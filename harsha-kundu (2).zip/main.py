
def push(stack,ele):
    stack.append(ele)
    print(ele, "inserted sucessfully")
    
def pop(stack):
    if len(stack) == 0:
        print("stack is emptied")
        return
    print(stack[-1],"deleted succesfully")
    stack.pop()
    
stack = []
push(stack,10)
push(stack,30)
push(stack,50)
push(stack,70)
push(stack,80)

print(stack)
pop(stack)
pop(stack)
pop(stack)
pop(stack)
pop(stack)
pop(stack)







def enQueue(Q, ele):
    Q.append(ele)
    print(ele,"success")
    
    
    
def pop(stack):
    if len(stack) == 0:
        print("stack is emptied")
        return
    print(stack[-1],"deleted succesfully")
    stack.pop()
    
    
Q = []
enQueue(Q,10)
enQueue(Q,50)
enQueue(Q,70)









def isBalanced(word):
    stack = []
    for ele in word:
        if ele == '(':
            stack.append(ele)
        else:
            if len(stack) == 0:
                return False
            else:
                stack.pop()
    if len(stack) == 0:
        return True
    return False
    
    
    
word = "()("
result = isBalanced(word)
print(result)
    
    
    
class Solution(object):
    def isValid(self, s):
        stack = []
        openBrackets = ["(", "{", "["]
        for ele in s:
            if ele in openBrackets:
                stack.append(ele)
            else:
                if len(stack) == 0:
                    return False 
                elif ele == ')':
                    if stack[-1] == '(':
                        stack.pop()
                    else:
                        return False
                elif ele == ']':
                    if stack[-1] == '[':
                        stack.pop()
                    else:
                        return False
                elif ele == '}':
                    if stack[-1] == '{':
                        stack.pop()
                    else:
                        return False
        if len(stack) == 0:
            return True 
        return False   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    























